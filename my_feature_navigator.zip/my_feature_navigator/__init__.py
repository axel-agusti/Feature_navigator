def classFactory(iface):
    from .my_feature_navigator import FeatureNavigator
    return FeatureNavigator(iface)
